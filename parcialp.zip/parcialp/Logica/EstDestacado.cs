﻿
using System.Collections.Generic;
using Entidades;
using System.Runtime.CompilerServices;
using Datos;


namespace Logica
{
    public class EstDestacado
    {
        private List<Persona> Persona;
        private Rdatos archivo;
   
        private List<string> materiasPost = new List<string>()
        {
            "DESARROLLO SOFTWARE", "DERECHO ADMINISTRATIVO", "AUDITORIA EN SALUD"
        };

        private List<string> materiasPre = new List<string>
        {
            "SISTEMAS", "DERECHO", "ENFERMERIA", "LICENCIATURA", "MUSICA"
        };

           
            public EstDestacado()
            {
                Persona = new List<Persona>();
                archivo = new Rdatos("Registro-Academico.dat");
                Registrar_Datos();
            }

            public List<Persona> Listar()
            {
                return  Persona;
            }

            private void Registrar_Datos()
            {
                    Persona = archivo.Registrar_Estudiante();
            }

            public string Promedio_Est(string Asig)
            {
                double promedio = 0;
                var EstOb = 0;

                foreach (var Cr9 in Persona)
                {
                    if (Cr9.Programa.Equals(Asig) && materiasPre.Contains(Asig))
                    {
                        var Cr2 = (Pregrado)Cr9;
                        var promEstudiantes = (Cr2.PromedioCorte1 + Cr2.PromedioCorte2 + Cr2.PromedioCorte3) / 3;
                        promedio += promEstudiantes;
                        EstOb += 1;
                    }
                    else if (Cr9.Programa.Equals(Asig) && materiasPost.Contains(Asig))
                    {
                        var Cr10 = (Postgrado)Cr9;
                        promedio += Cr10.PromedioSemestre;
                        EstOb += 1;
                    }
                }

                var Cr11 = promedio /  EstOb;
                return $"El promedio de {Asig} es {Cr11}";
            }

            public string EstuDestacado(string Asig )
            {
                double promaximo = 0;
                string Estudiantedestacado = " ";
                foreach (var Cr12 in Persona)
                {
                    double promEstudiante;
                    if (Cr12.Programa.Equals(Asig) && materiasPre.Contains(Asig))
                    {
                        var Cr3 = (Pregrado)Cr12;
                        promEstudiante = (Cr3.PromedioCorte1 + Cr3.PromedioCorte2 + Cr3.PromedioCorte3) / 3;

                        if (!(promEstudiante > promaximo)) continue;
                        promaximo = promEstudiante;
                        Estudiantedestacado = Cr3.Nombres;
                    }
                    else if (Cr12.Programa.Equals(Asig) && materiasPost.Contains(Asig))
                    {
                        var Cr13 = (Postgrado)Cr12;
                        promEstudiante = Cr13.PromedioSemestre;

                        if (!(promEstudiante > promaximo)) continue;
                        promaximo = promEstudiante;
                        Estudiantedestacado = Cr13.Nombres;
                    }
                }
                return $"El estudiante destacado es {Estudiantedestacado}";
            }
        }
    }


