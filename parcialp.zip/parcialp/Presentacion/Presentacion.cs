﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class Presentacion
    {
        private RepositorioPostgrado PPostgrado = new RepositorioPostgrado();
        private RepositorioPregrado PPregrado = new RepositorioPregrado();
        private PresentacionPersona PPersona = new PresentacionPersona();

        public void menu()

        {
            int op = 0;
            do
            {
                Console.Clear();
                Console.WriteLine("---------MENÚ-------------");
                Console.WriteLine("1. ESTUDIANTE DE PREGRADO ");
                Console.WriteLine("2. ESTUDIANTE DE POSTGRADO");
                Console.WriteLine("3. PROMEDIO DE PROGRAMA");
                Console.WriteLine("4. ESTUDIANTES DESTACADOS ");
                Console.WriteLine("5. SALIR");


                Console.Write("--------------- DIGITE SU OPCIÓN...-------------- ");
                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        PPregrado.Lista();
                        break;
                    case 2:
                        PPostgrado.Lista();
                        break;
                    case 3:
                        PPersona.Mostrar_Promedio();
                        break;
                    case 4:
                        PPersona.Mostrar_Destacado();
                        break;
                    case 5:
                        Console.Clear();
                        Console.WriteLine("GRACIAS, PROGRAMA DE JULIANA TORRES, Vuelva pronto !! ");
                        Console.ReadKey();
                        break;

                }
            } while (op != 5);

        }
     }
 }
