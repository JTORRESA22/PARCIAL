﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Logica;

namespace Presentacion
{
    public class PresentacionPersona
    {
        protected EstDestacado manejar = new EstDestacado();

        public void Mostrar_Promedio()
        {
            Console.Clear();

            Console.Write("Ingrese la materia que desea calcular promedio: ");
            var Cr15 = Console.ReadLine().ToUpper();

            Console.WriteLine(manejar.Promedio_Est(Cr15));
            Console.Write("Espacio, para continuar "); Console.ReadKey();
        }

        public void Mostrar_Destacado()
        {
            Console.Clear();

            Console.Write("Digite la Asignatura, estudiantes destacados: ");
            var Cr16 = Console.ReadLine().ToUpper();

            Console.WriteLine(manejar.EstuDestacado(Cr16));
            Console.Write("Espacio, para continuar "); Console.ReadKey();
        }
    }
  }

