﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;


namespace Presentacion
{
            public class RepositorioPostgrado : PresentacionPersona
        {
            public void Lista()
            {
                Console.Clear();
                Console.WriteLine("---------------ESTUDIANTES DE POSTGRADOS--------------");

                foreach (var Cr4 in manejar.Listar().Where(estudiante => estudiante.GetType() == typeof(Postgrado))
                             .Cast<Postgrado>())
                {
                    Console.WriteLine($"N_Documentos: {Cr4.N_Documentos}");
                    Console.WriteLine($"Nombres y Apellidos: {Cr4.Nombres} {Cr4.Apellidos}");
                    Console.WriteLine($"Programa: {Cr4.Programa}");
                    Console.WriteLine($"Semestre: {Cr4.Semestre}");
                    Console.WriteLine($"Promedio: {Cr4.PromedioSemestre}");

                    Console.WriteLine();
                }
                Console.Write("ESPACIO, PARA CONTINUAR "); Console.ReadKey();
            }
        }
    }

