﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Presentacion
{
    public class RepositorioPregrado : PresentacionPersona
    {
        public void Lista()
        {
            Console.Clear();
            Console.WriteLine("----------ESTUDIANTES DE PREGRADO---------------------");

            foreach (var cr1 in manejar.Listar().Where(estudiante => estudiante.GetType() == typeof(Pregrado)).Cast<Pregrado>())
            {
                Console.WriteLine($"N_Documento: {cr1.N_Documentos}");
                Console.WriteLine($"Nombres y Apellidos: {cr1.Nombres} {cr1.Apellidos}");
                Console.WriteLine($"Programa: {cr1.Programa}");
                Console.WriteLine($"Semestre: {cr1.Semestre}");
                Console.WriteLine($"Corte 1: {cr1.PromedioCorte1}");
                Console.WriteLine($"Corte 2: {cr1.PromedioCorte2}");
                Console.WriteLine($"Corte 3: {cr1.PromedioCorte3}");

                Console.WriteLine();
            }

            Console.Write("ESPACIO, PARA CONTINUAR"); Console.ReadKey();
        }
    }
}

