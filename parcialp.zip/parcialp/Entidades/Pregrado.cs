﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Pregrado : Persona
    {

        public Pregrado()
        {

        }
        public Pregrado(int n_Documento, string nombre, string apellido, string programapre, int semestre, double promedioCorte1, double promedioCorte2, double promedioCorte3)
        {

        }
        public override string ToString()
        {

            return $"PRE{N_Documentos};{Nombres};{Apellidos};{Semestre};{Programa};{PromedioCorte1};{PromedioCorte2};{PromedioCorte3}";

        }

        public double PromedioCorte1 { get; set; }
        public double PromedioCorte2 { get; set; }
        public double PromedioCorte3 { get; set; }


        public override void Registrar_Datos(string[] linea)
        {
            base.Registrar_Datos(linea);
            PromedioCorte1 = double.Parse(linea[6]);
            PromedioCorte2 = double.Parse(linea[7]);
            PromedioCorte3 = double.Parse(linea[8]);
        }

    }
}
