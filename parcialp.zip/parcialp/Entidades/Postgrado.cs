﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Postgrado:Persona
    {
        public Postgrado()
        {

        }
        public Postgrado(int n_Documento, string nombre, string apellido, string programapostg, int semestre, double promedioSemestre)
        {

        }
        public override string ToString()
        {

            return $"POST{N_Documentos};{Nombres};{Apellidos};{Semestre};{Programa};{PromedioSemestre}";

        }

        public double PromedioSemestre { get; set; }


        public override void Registrar_Datos(string[] linea)
        {
            base.Registrar_Datos(linea);
            PromedioSemestre = double.Parse(linea[6]);
        }

    }
}
