﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Persona
    {
        public Persona()
            {

            }


        public Persona(int semestre, string nombres, int n_Documento, string apellidos, String programa)
        {
            this.Semestre = semestre;
            this.Nombres = nombres;
            this.N_Documentos = n_Documento;
            this.Apellidos = apellidos;
            this.Programa = programa;
        }

        public override string ToString()
            {
                return $"{N_Documentos};{Nombres};{Apellidos};{Semestre}; {Programa}";
            }


            
            public String Nombres { get; set; }
            public String Apellidos { get; set; }
            public int N_Documentos { get; set; }
            public int Semestre { get; set; }
            public String Programa { get; set; }

        public virtual void Registrar_Datos(string[] data)
        {
            N_Documentos = int.Parse(data[1]);
            Nombres = data[2];
            Apellidos = data[3];
            Programa = data[4];
            Semestre = int.Parse(data[5]);
        }

    }
}
