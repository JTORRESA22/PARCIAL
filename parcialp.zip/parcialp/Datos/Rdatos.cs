﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;


namespace Datos
{
    public class Rdatos
    {
        private string ruta;
        private Persona persona;
        public Rdatos(string ruta)
        {
            this.ruta = ruta;
        }

        public List<Persona> Registrar_Estudiante()
        {

            var Carga= new StreamReader(ruta);
            var Cr8 = new List<Persona>();

            var Cr6 = Carga.ReadLine();
            while (Cr6 != null)
            {
                var Cr7 = Cr6.Split (';')[0];
                if (Cr7 == "PRE")
                {
                    persona = new Pregrado();
                    persona.Registrar_Datos(Cr6.Split(';'));
                }
                else
                {
                    persona = new Postgrado();
                    persona.Registrar_Datos(Cr6.Split(';'));
                }
                Cr8.Add(persona);
                Cr6 = Carga.ReadLine();
            }

            Carga.Close();
            return Cr8;
        }
    }
}